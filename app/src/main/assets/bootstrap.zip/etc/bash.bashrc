shopt -s histappend
shopt -s histverify

export HISTCONTROL=ignoreboth

PROMPT_DIRTRIM=2
PS1='\[\e[0;32m\]\w\[\e[0m\] \[\e[0;97m\]\$\[\e[0m\] '